﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ts
{
    public partial class Form1 : Form
    {
        string Player = "X";
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private void btn_Click(object sender, EventArgs e)
        {
            ((Button)sender).Text = Player;
            ((Button)sender).Enabled = false;
            isWin();
            Player = (Player == "X") ? "O" : "X";
        }
        bool isWin()
        {
            if (btn1.Text != " " && btn1.Text == btn2.Text && btn1.Text == btn3.Text) MessageBox.Show("", "");
            {
                if (btn1.Text != " " && btn1.Text == btn4.Text && btn1.Text == btn7.Text) MessageBox.Show("", "");
                {
                    if (btn1.Text != " " && btn1.Text == btn5.Text && btn1.Text == btn9.Text) MessageBox.Show("", "");
                    return true;
                }
            }
        }
    }
}